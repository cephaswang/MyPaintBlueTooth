Chart.js入门
============

## 课程详细

01. 课程介绍
02. Chart.js安装
03. Chart.js初体验
04. 画一个线图
05. 设定坐标轴
06. 标题和图例
07. 线形变换
08. 棒棒图
09. 线棒成一家
10. 雷达图
11. 圆饼图

## 课程文件

https://gitee.com/komavideo/LearnChartJS

## 小马视频频道

http://komavideo.com