package com.webianks.bluechat

/**
 * Created by ramankit on 25/7/17.
 */
data class Message(val message: String,val time: Long,val type: Int)