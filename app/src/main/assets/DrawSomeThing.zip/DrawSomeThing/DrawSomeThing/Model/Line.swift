//
//  Line.swift
//  DrawSomeThing
//
//  Created by admin on 2020/2/22.
//  Copyright © 2020 admin. All rights reserved.
//

//  Swift 4.2 Draw Something with CGContext and Canvas View
//  https://www.youtube.com/watch?v=E2NTCmEsdSE
//  https://www.youtube.com/watch?v=7vDfL0K6Jm8


import UIKit


struct Line {
    let strokeWidth: Float
    let color: UIColor
    var points:[CGPoint]
}


// Line(strokeWidth: <#T##Float#>, color: <#T##UIColor#>, points: <#T##[CGPoint]#>)
