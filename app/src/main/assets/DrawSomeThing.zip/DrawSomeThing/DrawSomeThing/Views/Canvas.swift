//
//  ViewController.swift
//  DrawSomeThing
//
//  Created by admin on 2020/2/22.
//  Copyright © 2020 admin. All rights reserved.

//  Swift 4.2 Draw Something with CGContext and Canvas View
//  https://www.youtube.com/watch?v=E2NTCmEsdSE
//  https://www.youtube.com/watch?v=7vDfL0K6Jm8



import UIKit

class Canvas: UIView {
    
    fileprivate var strokeColor: UIColor = UIColor.black
    fileprivate var strokeWidth: Float = 1
    
    func setStrokeWidth(width :Float){
        self.strokeWidth = width
    }
    func setStrokeColor(color: UIColor){
        self.strokeColor = color
    }
    
    func undo (){
        _ = lines.popLast()
        setNeedsDisplay()
    }
    
    
    func clear(){
        lines.removeAll()
        setNeedsDisplay()
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        guard let contex = UIGraphicsGetCurrentContext() else { return }
        
        //let startPont = CGPoint(x: 0,y: 0)
        //let endPoint = CGPoint(x: 100,y: 100)
       // contex.move(to: startPont)
       // contex.addLine(to: endPoint)

        lines.forEach{ (line) in
            
            contex.setStrokeColor(line.color.cgColor)
            contex.setLineWidth(CGFloat(line.strokeWidth))
            contex.setLineCap(.round)
            
            for(i,p) in line.points.enumerated() {
                if i == 0 {
                    contex.move(to: p)
                } else {
                    contex.addLine(to: p)
                }
            }
            contex.strokePath()
        }
        

    }
    
    fileprivate var lines = [Line]()
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        lines.append( Line.init(strokeWidth: strokeWidth, color: strokeColor, points: []) )
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let point = touches.first?.location(in: nil) else { return }
        
        guard var lastLine = lines.popLast() else { return }
        lastLine.points.append(point)
        lines.append(lastLine)
        print(point)
        setNeedsDisplay()
        
    }
}

