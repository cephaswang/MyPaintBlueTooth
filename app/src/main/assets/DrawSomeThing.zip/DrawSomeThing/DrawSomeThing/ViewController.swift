//
//  ViewController.swift
//  DrawSomeThing
//
//  Created by admin on 2020/2/22.
//  Copyright © 2020 admin. All rights reserved.

//  Swift 4.2 Draw Something with CGContext and Canvas View
//  https://www.youtube.com/watch?v=E2NTCmEsdSE
//  https://www.youtube.com/watch?v=7vDfL0K6Jm8

import UIKit


class ViewController: UIViewController {
    
   let canvas = Canvas()
    
    let undoButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Undo", for: .normal)
        button.titleLabel?.font = .boldSystemFont(ofSize: 14)
        button.addTarget(self, action: #selector(handleUndo), for: .touchUpInside)
        return button
    }()
    
    @objc fileprivate func handleUndo (){
        print("Undo lines drawn")
        
        //canvas.lines.removeAll()
        //canvas.setNeedsDisplay()
        
        canvas.undo()
    }
    
    let clearButton: UIButton = {
           let button = UIButton(type: .system)
           button.setTitle("Clear", for: .normal)
           button.titleLabel?.font = .boldSystemFont(ofSize: 14)
           button.addTarget(self, action: #selector(handleclear), for: .touchUpInside)
           return button
    }()
    
    @objc fileprivate func handleclear (){
        print("Undo lines drawn")
        canvas.clear()
    }
    
    
    let yellowButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .yellow
        button.layer.borderWidth = 1
        // button.setTitle("Clear", for: .normal)
        // button.titleLabel?.font = .boldSystemFont(ofSize: 14)
        button.addTarget(self, action: #selector(handleColorChange), for: .touchUpInside)
        return button
    }()
    
    let redButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .red
        button.layer.borderWidth = 1
        // button.setTitle("Clear", for: .normal)
        // button.titleLabel?.font = .boldSystemFont(ofSize: 14)
        button.addTarget(self, action: #selector(handleColorChange), for: .touchUpInside)
        return button
    }()
    
    let blueButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .blue
        button.layer.borderWidth = 1
        button.addTarget(self, action: #selector(handleColorChange), for: .touchUpInside)
        return button
    }()
    
    let slider: UISlider = {
        let slider = UISlider()
        slider.minimumValue = 1
        slider.maximumValue = 10
        // slider.backgroundColor = .blue
        // slider.layer.borderWidth = 1
        slider.addTarget(self, action: #selector(handleSliderChange), for: .valueChanged)
        return slider
    }()
    
    
    
    @objc func handleSliderChange (slider: UISlider){
        print(slider.value)
        canvas.setStrokeWidth(width: slider.value)
    }
    
    @objc func handleColorChange (button: UIButton){
        canvas.setStrokeColor(color: button.backgroundColor ?? .black)
    }
    
    
    override func loadView() {
        self.view = canvas
    }
    // @IBOutlet weak var canvar: Canvas!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
       // view.addSubview(canvas)
        canvas.backgroundColor = .white
        
        setupLayout()
       // stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
       // stackView.trailingAnchor
        
        
    }

    
    fileprivate func setupLayout() {
        //  canvas.frame = view.frame
        let colorsStackView:UIStackView = UIStackView(arrangedSubviews: [
            yellowButton,
            redButton,
            blueButton
            ]
        )
        colorsStackView.distribution = .fillEqually
        
        let stackView:UIStackView = UIStackView(arrangedSubviews: [
            undoButton,
            clearButton,
            colorsStackView,
            slider
            ]
        )
        stackView.spacing = 12
        stackView.distribution = .fillEqually
        
        view.addSubview(stackView)
        // stackView.frame = CGRect(x: 0,y: 0,width: 200,height: 100)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor , constant: -8).isActive = true
    }
    

}

